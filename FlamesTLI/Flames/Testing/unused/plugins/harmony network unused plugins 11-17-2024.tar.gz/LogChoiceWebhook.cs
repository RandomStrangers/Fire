//reference System.Net.dll
//reference System.dll
//reference Newtonsoft.Json.dll
using System;
using System.IO;
using System.Net;
using Flames;
using Newtonsoft.Json;

namespace Core {
	public class LogChoiceWebhook : Plugin {
        
        public override string creator { get { return ""; } }
        public override string name { get { return "LogChoiceWebhook"; } }

        public override void Load(bool startup) {
        	HookLogger();
        }
        
        public void HookLogger() {
            
		    Logger.LogHandler += RelayLog;
		}
		
        public static void RelayLog(LogType type, string relaymessage) {
            if (type != LogType.Debug) return;
            if (relaymessage.CaselessContains("**Harmony Network**:")) return;
			if (relaymessage.CaselessContains("Harmony Network:")) return;
            string webhookUrl = "https://discord.com/api/webhooks/1181354716861567096/0rmdVlyggOAbTNt-Hu7w73hPBJC0jOqhJ0zCoHgHyG1-YwxAqpcp6khU7wmGWat3Zapv";
            string message = relaymessage;
            try { sendRequest(webhookUrl, message); } catch {}
        }

        public static void sendRequest(string URL, string msg) {
     		using (DiscordWeb dcWeb = new DiscordWeb()) {
         		dcWeb.ProfilePicture = "https://files.catbox.moe/6uiix1.png";
         		dcWeb.UserName = Server.Config.Name;
         		dcWeb.WebHook = URL;
         		dcWeb.SendMessage(msg);
      		}
   		}
            public override void Unload(bool shutdown) {
            Logger.LogHandler -= RelayLog;
Logger.Log(LogType.SystemActivity, "LogChoice webhook unloaded!");
        }
    }
	
	public class DiscordWeb : IDisposable {
        public WebClient wc;
        public string WebHook, UserName, ProfilePicture;
        
        public class DiscordMessage {
        	public string username;
        	public string avatar_url;
        	public string content;
        }

        public DiscordWeb() {
            wc = new WebClient();
        }

       public string ToJson(string message) {
        	DiscordMessage msg = new DiscordMessage();
        	msg.username = UserName;
        	msg.avatar_url = "https://files.catbox.moe/6uiix1.png";
        	msg.content = message;
			return JsonConvert.SerializeObject(msg);
        }

public void LogFailure(WebException ex) {
			try {
				string msg = new StreamReader(ex.Response.GetResponseStream()).ReadToEnd();
				Logger.Log(LogType.Warning, "Error sending Discord webhook: " + msg);
			} catch {
			}
		}
        
        public void SendMessage(string msgSend) {
			wc.Headers[HttpRequestHeader.ContentType] = "application/json";
			try {
	        		wc.UploadString(WebHook, ToJson(msgSend));
			} catch (WebException ex) {
				LogFailure(ex);
				throw;
			}
        }

        public void Dispose() {
            wc.Dispose();
        }
    }    
}
